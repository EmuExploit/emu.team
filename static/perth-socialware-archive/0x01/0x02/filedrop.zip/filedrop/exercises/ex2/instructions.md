# Exercise 2 Instructions

- Fix the file
  - It should print the numbers from 1 to 9 inclusive
- Compile the program by running `make`
- If something screws up, run `make clean` to start again from the source file
