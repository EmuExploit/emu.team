#!/bin/bash

sudo apt install nasm gcc


