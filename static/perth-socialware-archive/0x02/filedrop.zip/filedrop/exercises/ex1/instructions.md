# Exercise 1 Instructions

- Fix the file
- Compile the program by running `make`
- If something screws up, run `make clean` to start again from the source file
