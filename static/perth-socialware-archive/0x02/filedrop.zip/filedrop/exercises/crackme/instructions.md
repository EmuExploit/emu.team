# Crackme Instructions

- Find the 4 digit number you need to enter to print the `correct` message
- Compile the program by running `make`
- If something screws up, run `make clean` to start again from the source file
