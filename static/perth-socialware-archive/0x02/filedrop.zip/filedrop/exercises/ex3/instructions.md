# Exercise 3 Instructions

- Fix the file
  - It should print every even number
- Compile the program by running `make`
- If something screws up, run `make clean` to start again from the source file
