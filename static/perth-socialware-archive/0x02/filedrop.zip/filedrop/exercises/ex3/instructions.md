# Exercise 3 Instructions

- Fix the file
  - It should print every even number (between 1 and 9)
- Compile the program by running `make`
- If something screws up, run `make clean` to start again from the source file
